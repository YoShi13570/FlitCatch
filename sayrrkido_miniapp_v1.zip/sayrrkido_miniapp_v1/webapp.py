import os, sqlite3, json, hmac, hashlib, time
from urllib.parse import parse_qsl
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent
BOT_DIR = Path(os.getenv("BOT_DIR", str(ROOT)))
DB_PATH = Path(os.getenv("BOT_DB_PATH", str(BOT_DIR / "game_bot.db")))
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
MAX_AUTH_AGE = int(os.getenv("TG_AUTH_MAX_AGE", "86400"))

app = FastAPI(title="FLIT Catcher Mini App API")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

def db():
    con = sqlite3.connect(str(DB_PATH), timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    return con

def verify_init_data(init_data: str) -> dict:
    if not BOT_TOKEN:
        raise HTTPException(503, "Server BOT_TOKEN is not configured")
    if not init_data:
        raise HTTPException(401, "Telegram authentication is required")
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash", "")
        auth_date = int(pairs.get("auth_date", "0"))
        if not received_hash or not auth_date or time.time() - auth_date > MAX_AUTH_AGE or auth_date > time.time() + 60:
            raise ValueError("Expired or invalid auth data")
        data_check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret_key, data_check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            raise ValueError("Signature mismatch")
        user = json.loads(pairs["user"])
        uid = int(user["id"])
        return {"id": uid, "first_name": user.get("first_name", "Player"),
                "username": user.get("username", "")}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "Telegram authentication failed")

def current_user(authorization: Optional[str]):
    if not authorization or not authorization.startswith("tma "):
        raise HTTPException(401, "Missing Telegram initData")
    return verify_init_data(authorization[4:])

def ensure_user(con, user):
    con.execute("""INSERT INTO users(user_id,username,first_name)
        VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET
        username=excluded.username, first_name=excluded.first_name""",
        (user["id"], user.get("username",""), user.get("first_name","Player")))

def char_dict(row):
    return {"id": row["id"], "name": row["name"], "anime": row["anime"],
            "rarity": row["rarity"], "type": row["type"] or "",
            "media_type": row["media_type"], "file_id": row["file_id"]}

@app.get("/")
def index():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/me")
def me(authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization)
    con = db()
    try:
        ensure_user(con, user)
        row = con.execute("SELECT coins,gemstones FROM users WHERE user_id=?", (user["id"],)).fetchone()
        total = con.execute("SELECT COALESCE(SUM(quantity),0) n FROM owned_characters WHERE user_id=?", (user["id"],)).fetchone()["n"]
        unique = con.execute("SELECT COUNT(*) n FROM owned_characters WHERE user_id=?", (user["id"],)).fetchone()["n"]
        con.commit()
        return {"user": user, "coins": int(row["coins"]), "gems": int(row["gemstones"]),
                "total_cards": int(total), "unique_cards": int(unique)}
    finally:
        con.close()

@app.get("/api/harem")
def harem(authorization: Optional[str] = Header(default=None), limit: int = 60, offset: int = 0):
    user = current_user(authorization)
    limit = max(1, min(int(limit), 100)); offset = max(0, int(offset))
    con = db()
    try:
        rows = con.execute("""SELECT c.id,c.name,c.anime,c.rarity,c.type,c.media_type,c.file_id,o.quantity
            FROM owned_characters o JOIN characters c ON c.id=o.character_id
            WHERE o.user_id=? AND o.quantity>0 ORDER BY c.id DESC LIMIT ? OFFSET ?""",
            (user["id"], limit, offset)).fetchall()
        return {"items": [dict(char_dict(r), quantity=int(r["quantity"])) for r in rows],
                "offset": offset, "limit": limit}
    finally:
        con.close()

@app.get("/api/market")
def market(authorization: Optional[str] = Header(default=None)):
    current_user(authorization)
    con = db()
    try:
        rows = con.execute("""SELECT m.code,m.character_id,m.seller_id,m.price,
            COALESCE(m.currency,'coins') currency,c.name,c.anime,c.rarity,c.type,c.media_type,c.file_id,
            u.first_name seller_name
            FROM character_market m JOIN characters c ON c.id=m.character_id
            LEFT JOIN users u ON u.user_id=m.seller_id
            WHERE m.status='active' ORDER BY m.created_at DESC LIMIT 100""").fetchall()
        return {"items": [dict(r) for r in rows]}
    finally:
        con.close()

class BuyRequest(BaseModel):
    code: str

@app.post("/api/market/buy")
def market_buy(payload: BuyRequest, authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization); uid = user["id"]; code = payload.code.strip().upper()
    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("""SELECT m.*,c.name,c.rarity FROM character_market m
            JOIN characters c ON c.id=m.character_id WHERE m.code=? AND m.status='active'""", (code,)).fetchone()
        if not row: raise HTTPException(404, "Listing is no longer available")
        seller, cid, price = int(row["seller_id"]), int(row["character_id"]), int(row["price"])
        currency = row["currency"] if "currency" in row.keys() else "coins"
        wallet = "gemstones" if currency == "gemstones" else "coins"
        if seller == uid: raise HTTPException(400, "You cannot buy your own listing")
        buyer_row = con.execute(f"SELECT {wallet} FROM users WHERE user_id=?", (uid,)).fetchone()
        seller_row = con.execute(f"SELECT {wallet} FROM users WHERE user_id=?", (seller,)).fetchone()
        owned = con.execute("SELECT quantity,locked FROM owned_characters WHERE user_id=? AND character_id=?", (seller,cid)).fetchone()
        if not buyer_row or int(buyer_row[wallet]) < price: raise HTTPException(400, "Not enough balance")
        if not seller_row or not owned or int(owned["quantity"]) < 1: raise HTTPException(409, "Seller no longer owns this card")
        if owned["locked"]: raise HTTPException(409, "This character is locked")
        cur = con.execute("UPDATE character_market SET status='sold' WHERE code=? AND status='active'", (code,))
        if cur.rowcount != 1: raise HTTPException(409, "Listing was already purchased")
        con.execute(f"UPDATE users SET {wallet}={wallet}-? WHERE user_id=?", (price,uid))
        con.execute(f"UPDATE users SET {wallet}={wallet}+? WHERE user_id=?", (price,seller))
        con.execute("UPDATE owned_characters SET quantity=quantity-1 WHERE user_id=? AND character_id=?", (seller,cid))
        con.execute("DELETE FROM owned_characters WHERE user_id=? AND character_id=? AND quantity<=0", (seller,cid))
        existing=con.execute("SELECT quantity FROM owned_characters WHERE user_id=? AND character_id=?", (uid,cid)).fetchone()
        if existing: con.execute("UPDATE owned_characters SET quantity=quantity+1,last_caught_at=CURRENT_TIMESTAMP WHERE user_id=? AND character_id=?", (uid,cid))
        else: con.execute("INSERT INTO owned_characters(user_id,character_id,quantity) VALUES(?,?,1)", (uid,cid))
        con.commit()
        return {"ok": True, "message": f"Purchased {row['name']}", "price": price, "currency": currency}
    except HTTPException:
        con.rollback(); raise
    finally:
        con.close()

@app.get("/api/auctions")
def auctions(authorization: Optional[str] = Header(default=None)):
    current_user(authorization)
    con = db()
    try:
        rows = con.execute("""SELECT a.auction_id,a.seller_id,a.highest_bidder_id,a.highest_bid,
            a.starting_price,a.ends_at,c.id character_id,c.name,c.anime,c.rarity,c.type
            FROM auctions a JOIN characters c ON c.id=a.character_id
            WHERE a.status='active' AND a.ends_at>? ORDER BY a.ends_at ASC LIMIT 100""", (time.time(),)).fetchall()
        return {"items": [dict(r) for r in rows]}
    finally:
        con.close()

class BidRequest(BaseModel):
    amount: int

@app.post("/api/auction/{auction_id}/bid")
def auction_bid(auction_id: int, payload: BidRequest, authorization: Optional[str] = Header(default=None)):
    user = current_user(authorization); uid = user["id"]; bid = int(payload.amount)
    if bid <= 0: raise HTTPException(400, "Enter a valid bid")
    con = db()
    try:
        con.execute("BEGIN IMMEDIATE")
        auction = con.execute("SELECT * FROM auctions WHERE auction_id=? AND status='active'", (auction_id,)).fetchone()
        if not auction or float(auction["ends_at"]) <= time.time(): raise HTTPException(404, "Auction has ended")
        if uid == int(auction["seller_id"]): raise HTTPException(400, "You cannot bid on your own auction")
        current = int(auction["highest_bid"])
        if bid <= current: raise HTTPException(400, f"Bid must be higher than {current:,} coins")
        old_bidder = auction["highest_bidder_id"]
        old_bid = current if old_bidder else 0
        required = bid - old_bid if old_bidder and int(old_bidder) == uid else bid
        wallet = con.execute("SELECT coins FROM users WHERE user_id=?", (uid,)).fetchone()
        if not wallet or int(wallet["coins"]) < required: raise HTTPException(400, "Not enough coins for this bid")
        con.execute("UPDATE users SET coins=coins-? WHERE user_id=?", (required,uid))
        if old_bidder and int(old_bidder) != uid:
            con.execute("UPDATE users SET coins=coins+? WHERE user_id=?", (old_bid,int(old_bidder)))
        con.execute("UPDATE auctions SET highest_bidder_id=?,highest_bid=? WHERE auction_id=?", (uid,bid,auction_id))
        con.commit()
        return {"ok": True, "message": f"Your bid of {bid:,} coins is now highest"}
    except HTTPException:
        con.rollback(); raise
    finally:
        con.close()

@app.get("/api/rdb/info")
def rdb_info(authorization: Optional[str] = Header(default=None)):
    current_user(authorization)
    # Read-only overview; no paid random opening endpoint is exposed in this Mini App.
    return {"modes":[
        {"id":1,"cost":2500,"range":"Common – Universal"},
        {"id":2,"cost":3500,"range":"Common – Infinity"},
        {"id":3,"cost":20000,"range":"Divine – Universal"},
        {"id":4,"cost":75000,"range":"Crossverse – Infinity"}
    ],"note":"RDB opening is not enabled in the Mini App build."}
