FLIT CATCHER MINI APP v1
========================

ဒီ package က sayrrkido_bot_complete_v8.py ရဲ့ game_bot.db ကိုပဲ အသုံးပြုတဲ့
Mini App API + HTML frontend ဖြစ်ပါတယ်။

ပါဝင်တာ
- Telegram initData ကို HMAC ဖြင့် server-side စစ်ဆေးခြင်း
- Profile balance / Harem ကြည့်ခြင်း
- Market listing ကြည့်ခြင်း၊ Coin/Gem ဖြင့် ဝယ်ခြင်း
- Auction ကြည့်ခြင်း၊ Coin bid တင်ခြင်း
- RDB mode/cost ကြည့်ရန်သာ (Mini App ကနေ paid random opening ကို မဖွင့်ထားပါ)

အရေးကြီး
1) Bot ကို လက်ရှိ run နေတဲ့ host မှာ game_bot.db တစ်ခုတည်းကို အသုံးပြုပါ။
2) Mini App API server ကိုလည်း အဲဒီ host ပေါ်မှာ run ပါ။ SQLite DB ကို host မတူတဲ့နေရာမှာ
   copy လုပ်ပြီး သီးခြားသုံးရင် balance/listing မတူတော့နိုင်ပါ။
3) BOT_TOKEN ကို environment variable ထဲမှာ ထည့်ပါ။ Source code ထဲ မရေးပါနဲ့။
4) BOT_DIR ကို bot.py ရှိတဲ့ folder path ထားပါ။ BOT_DB_PATH ကို bot နဲ့ webapp နှစ်ခုလုံးမှာ game_bot.db ရဲ့ တူညီတဲ့ absolute path အဖြစ် သတ်မှတ်ပါ။ v9 bot က BOT_DB_PATH ကို လက်ခံပါတယ်။
5) HTTPS hosting မရှိသေးလို့ Telegram Mini App URL ကို အခုချက်ချင်း ချိတ်လို့မရသေးပါ။

Local run:
  pip install -r requirements.txt
  export BOT_TOKEN="YOUR_BOT_TOKEN"
  export BOT_DIR="/path/to/folder/containing/sayrrkido_bot_complete_v8.py"
  uvicorn webapp:app --host 0.0.0.0 --port 8000

BotFather မှာ HTTPS URL ရလာပြီးမှ /setmenubutton သို့မဟုတ် bot ရဲ့ Web App button မှာ
အဲဒီ URL ကို သတ်မှတ်ပါ။

Bot command:
  /miniapp
ဒီ command က MINI_APP_URL environment variable သတ်မှတ်ပြီး bot patch ထည့်ပြီးမှ အလုပ်လုပ်မည်။

Security:
- Frontend က balance ကို တိုက်ရိုက်မပြောင်းနိုင်ပါ။
- Every API request verifies Telegram initData.
- Market purchase / auction bid use SQLite BEGIN IMMEDIATE transaction.
- Hosting မှာ persistent disk မရှိရင် SQLite မသုံးပါနဲ့။
